---
name: Bengal Vanguard
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#5e3f3c'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#926e6a'
  outline-variant: '#e7bcb8'
  surface-tint: '#c00014'
  primary: '#bc0014'
  on-primary: '#ffffff'
  primary-container: '#e61b23'
  on-primary-container: '#fffcff'
  inverse-primary: '#ffb4ab'
  secondary: '#b22b1d'
  on-secondary: '#ffffff'
  secondary-container: '#fe624e'
  on-secondary-container: '#650000'
  tertiary: '#705d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#c9a900'
  on-tertiary-container: '#4c3f00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000d'
  secondary-fixed: '#ffdad4'
  secondary-fixed-dim: '#ffb4a8'
  on-secondary-fixed: '#410000'
  on-secondary-fixed-variant: '#8f0f07'
  tertiary-fixed: '#ffe16d'
  tertiary-fixed-dim: '#e9c400'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#544600'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  title-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

This design system is built for a political movement that balances tradition with a forward-looking digital presence. The brand personality is **authoritative, patriotic, and empowering**, designed to inspire trust and collective action. 

The visual style is a blend of **Corporate Modern** and **High-Contrast Bold**. It utilizes clean layouts and significant whitespace to ensure information clarity, while using aggressive color blocks and sharp accents to convey strength. The aesthetic avoids unnecessary ornamentation, focusing instead on structural integrity and clear hierarchy to reflect a disciplined political organization.

## Colors

The palette is rooted in the "TVK Red," symbolizing energy and courage, paired with a "TVK Maroon" to provide depth and a sense of established history.

- **Primary (TVK Red):** Used for primary actions, critical alerts, and brand identity elements.
- **Secondary (TVK Maroon):** Used for secondary backgrounds, headers, and depth-building gradients.
- **Accent (Gold):** Reserved for highlights, membership tiers, and successful validation states.
- **Neutral (Slate/Navy):** Provides high-contrast legibility for all body text and interface borders.
- **Background:** A crisp off-white (#F8FAFC) is used to maintain a clean, institutional feel.

## Typography

The design system utilizes **Inter** for its systematic and utilitarian qualities, ensuring high legibility across both English and Bengali scripts.

- **Headlines:** Use Bold and Extra Bold weights with tight letter-spacing to create an impactful, "front-page" editorial feel.
- **Body Text:** Standardizes on a 16px base to ensure accessibility for a wide demographic range.
- **Bengali Support:** When rendering Bengali, line-heights should be increased by 10% to accommodate conjunct characters and vowel markers without clipping.
- **Labels:** Use semi-bold uppercase treatment for secondary navigation and form descriptors to differentiate from content.

## Layout & Spacing

The system employs a **12-column fluid grid** for desktop and a **4-column grid** for mobile. 

- **Grid Logic:** Content should be centered within a 1280px max-width container. 
- **Rhythm:** An 8px linear scale (8, 16, 24, 32, 48, 64, 80) governs all margins and padding to ensure mathematical harmony.
- **Mobile Reflow:** For mobile views, vertical stacks are mandatory. Cards and inputs must span the full width of the safe area (minus margins).

## Elevation & Depth

This design system uses **Tonal Layers** and **Low-Contrast Outlines** to maintain a professional, flat-ish appearance, with one notable exception:

1.  **Surfaces:** Most containers use a subtle 1px border (#E2E8F0) rather than heavy shadows.
2.  **Interaction Depth:** Elements like primary buttons use a small, 2px offset "hard shadow" of the primary color to simulate a physical press.
3.  **Special Components:** The Digital Membership Card is the only element permitted to use a **Glassmorphism** effect—featuring a backdrop blur (12px) and a semi-transparent Maroon gradient to signify its "premium" status.

## Shapes

The shape language is **Soft (0.25rem)**. This provides a subtle modern touch without appearing too "playful" or "casual."

- **Buttons & Inputs:** Use the standard 4px (0.25rem) radius.
- **Cards & Modals:** Use `rounded-lg` (8px/0.5rem) to provide a clear container definition.
- **Selection Indicators:** Checkboxes and radio buttons should maintain a strict geometric profile to feel institutional and precise.

## Components

### Buttons
- **Primary:** TVK Red background, white text. On hover, shifts to TVK Maroon.
- **Secondary:** White background with a 2px TVK Maroon border.
- **Animation:** Use a 200ms ease-in-out transition for all hover states.

### Digital Membership Card
- **Background:** A deep Maroon gradient with a 20% opacity white noise texture.
- **Effects:** Backdrop-filter: blur(15px).
- **Details:** Gold foil-effect logo in the top right, with monospaced text for the ID number to emphasize a "secure" feel.

### Form Inputs
- **State:** Default borders are Slate-300. On focus, borders transition to TVK Red with a 2px outer glow.
- **Validation:** Error states use a high-saturation red; success states use Gold/Yellow icons.

### OTP Verification Modal
- **Layout:** Centered modal with a dark semi-transparent overlay.
- **Input:** Six individual boxes for digits, featuring a 2px bottom-border highlight for the active digit.
- **Footer:** Includes a countdown timer in Maroon and a "Resend" link that remains disabled until the timer expires.

### Lists
- Standardize on "Identity Lists"—each list item should have a small vertical TVK Red bar on the left to denote "active" or "important" status.